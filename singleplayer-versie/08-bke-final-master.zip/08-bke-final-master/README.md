# MODULE 08 - JavaScript & Games
  
|   	|   	|
|---	|---	|
| _Versie_  	| December 2021  	|
| _Auteur_  	| J.J. Strootman  	|  
  
## Mappen
* __Afbeeldingen__  
  Bevat source afbeeldingen voor de applicatie  
    
* **bke-student**  
  De bronbestanden voor studenten  

* **css**  
  De stylesheet voor de docentenversie  

* **img**  
  De afbeeldingen gebruikt in de web applicatie  

* **js**  
  Bevat de JavaScript code van de docenten versie
  
* **fonts**  
  Een verzamelen fonts voor gebruik in de UI  

